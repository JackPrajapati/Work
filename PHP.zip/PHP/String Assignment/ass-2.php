<?php
    echo "2. Write a PHP script to check if a string contains a specific string? ";
    $str = "The quick brown fox jumps over the lazy dog.";
    echo '<br>';

    if(strpos($str,'jumps') !== false)
    {
        echo "Jumps is a substring of $str.";
        echo '<br>';
    }
    else
    {
        echo '<br>';
        echo "Jumps is not a substring of $str.";
    }
?>