<?php
    echo "17. Write a PHP script to remove comma(s) from the following numeric string.";
    echo "<br>";
    echo $str = '2,543.12';
    echo "<br>";
    $str = str_replace(',','',$str);
    echo $str;
?>
