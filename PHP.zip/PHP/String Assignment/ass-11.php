<?php
    echo "11. Write a PHP script to get the first word of a sentence. ";
    echo "<br>";
    $str = 'The quick brown fox';
    $word = explode(' ',trim($str));
    echo $word[0]."\n";


?>
