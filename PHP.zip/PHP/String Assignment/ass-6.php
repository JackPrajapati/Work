<?php
    echo "6. Write a PHP script to generate simple random password  from a given string. ";
    echo "\n";

    function password_generate($chars)
    {
        $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        return substr(str_shuffle($data),0,$chars);
    }

    echo "\n"."Password:";

    echo password_generate(8)."\n";
?>