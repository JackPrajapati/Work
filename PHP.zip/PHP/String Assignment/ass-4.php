<?php
    echo "4. Write a PHP script to extract the user name from the following email ID. "."<br>";
    $str = 'rayy@example.com';
    echo $str;
    echo "<br>";

    $substr = strstr($str,'@',true);

    echo $substr;
?>