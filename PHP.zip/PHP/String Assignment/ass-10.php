<?php 
    echo "10. Write a PHP script to remove a part of a string from the beginning.";
    $str ='rayy@example.com';
    echo "<br>";

    $sub_string = 'rayy@';
    if (substr($str, 0, strlen($sub_string)) == $sub_string) 
    {
        $str = substr($str, strlen($sub_string));
    }
    echo $str."\n";
    
?>