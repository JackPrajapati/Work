<?php
    echo "14. Write a PHP script to remove trailing slash from a string.";
    $str = 'The quick brown fox jumps over the lazy dog///';
    echo $str;
    echo "<br>";
    $str_new = rtrim($str,'/');
    echo $str_new;
?>