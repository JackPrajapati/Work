<?php
    echo "9. Write a PHP script to get the filename component of the following path. ";
    $path = "https://www.w3resource.com/index.php";
    echo "<br>";
    echo $path;
    echo "<br>";
    $file = basename($path,".php");
    echo $file;
?>