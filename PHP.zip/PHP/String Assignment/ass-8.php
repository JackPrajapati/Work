<?php
    echo "8. Write a PHP script to put a string in an array. ";
    $str = "Twinkle, twinkle, little star,\nHow I wonder what you are.\nUp above the world so high,\nLike a diamond in the sky.";
    $new_array = explode("\n",$str);
    echo "<pre>";
    var_dump($new_array);
    echo "</pre>";

?>