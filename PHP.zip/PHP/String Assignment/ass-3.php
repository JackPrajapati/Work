<?php
    echo '3. Write a PHP script to extract the file name from the following string.';
    $str = 'www.example.com/public_html/index.php';
    echo "<br>"."$str"."<br>";
    $extract = substr(strrchr($str,"/"),1);
    echo "<br>";
    echo $extract."\n";

?>