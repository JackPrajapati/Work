<?php
    echo "18. Write a PHP script to print letters from 'a' to 'z'. ";
    
    for($i=97;$i<123;$i++){
        echo "<br>".chr($i);
    }

?>
