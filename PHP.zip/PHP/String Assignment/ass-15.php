<?php 
    echo "15. Write a PHP script to get the characters after the last '/' in an url. ";
    echo "<br>";
    $str = 'http://www.example.com/5478631';
    echo $str."<br>";
    echo substr($str,strrpos($str,'/')+1)."\n";
?>