<?php
    echo 'Hello world';
    echo '<br>';
    $str = "This is demo String...";
        
    //1.1
    echo "a)transform a string all uppercase letters.  ";
    echo '<br>';
    echo strtoupper("$str");
    echo '<br>';

    //1.2
    echo "b)transform a string all lowercase letters. ";
    echo '<br>';
    echo strtolower("$str");
    echo '<br>';

    //1.3
    echo "c) make a string's first character uppercase.";
    echo '<br>';
    echo ucwords("$str");
    echo '<br>';

    //1.4
    echo "D)make a string's first character of all the words uppercase.";
    echo '<br>';
    echo ucfirst("$str");
    echo '<br>';

?>

<?php
    echo "2. Write a PHP script to check if a string contains a specific string? ";
    $str = "The quick brown fox jumps over the lazy dog.";
    echo '<br>';

    if(strpos($str,'jumps') !== false)
    {
        echo "Jumps is a substring of $str.";
        echo '<br>';
    }
    else
    {
        echo '<br>';
        echo "Jumps is not a substring of $str.";
    }
?>

<?php
    echo '3. Write a PHP script to extract the file name from the following string.';
    $str = 'www.example.com/public_html/index.php';
    echo "<br>"."$str"."<br>";
    $extract = substr(strrchr($str,"/"),1);
    echo "<br>";
    echo $extract."\n";

?>

<?php
    echo "4. Write a PHP script to extract the user name from the following email ID. "."<br>";
    $str = 'rayy@example.com';
    echo $str;
    echo "<br>";

    $substr = strstr($str,'@',true);

    echo $substr;
?>

<?php
    echo "5. Write a PHP script to get the last three characters of a string. ";
    echo "<br>";
    $str = "ray@example.com";
    echo "<br>";
    $strnew = substr($str,-3);
    echo $strnew;
?>

<?php
    echo "6. Write a PHP script to generate simple random password  from a given string. ";
    echo "\n";

    function password_generate($chars)
    {
        $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        return substr(str_shuffle($data),0,$chars);
    }

    echo "\n"."Password:";

    echo password_generate(8)."\n";
?>

<?php
    echo "7. Write a PHP script to replace the first 'the' of the following string with 'That'.";
    $str = 'the quick brown fox jumps over the lazy dog.';
    echo "<br>";    
    echo $str;
    echo "<br>";
    echo preg_replace('/the/','That',$str,1)."\n";
?>

<?php
    echo "8. Write a PHP script to put a string in an array. ";
    $str = "Twinkle, twinkle, little star,\nHow I wonder what you are.\nUp above the world so high,\nLike a diamond in the sky.";
    $new_array = explode("\n",$str);
    echo "<pre>";
    var_dump($new_array);
    echo "</pre>";

?>

<?php
    echo "9. Write a PHP script to get the filename component of the following path. ";
    $path = "https://www.w3resource.com/index.php";
    echo "<br>";
    echo $path;
    echo "<br>";
    $file = basename($path,".php");
    echo $file;
?>

<?php 
    echo "10. Write a PHP script to remove a part of a string from the beginning.";
    $str ='rayy@example.com';
    echo "<br>";

    $sub_string = 'rayy@';
    if (substr($str, 0, strlen($sub_string)) == $sub_string) 
    {
        $str = substr($str, strlen($sub_string));
    }
    echo $str."\n";
    
?>

<?php
    echo "11. Write a PHP script to get the first word of a sentence. ";
    echo "<br>";
    $str = 'The quick brown fox';
    $word = explode(' ',trim($str));
    echo $word[0]."\n";


?>

<?php 
    echo "12. Write a PHP script to remove all leading zeroes from a string. ";
    echo "<br>";
    $str = '000547023.24';
    $str_new = ltrim($str,'0');
    echo $str."<br>".$str_new;  
?>

<?php
    echo "13. Write a PHP script to remove part of a string.";
    echo "<br>";
    $str = 'The quick brown fox jumps over the lazy dog';
    echo $str."<br>";
    $strr = 'for';
    $new_str = str_replace('fox',' ',$str);
    echo $new_str;

?>

<?php
    echo "14. Write a PHP script to remove trailing slash from a string.";
    $str = 'The quick brown fox jumps over the lazy dog///';
    echo $str;
    echo "<br>";
    $str_new = rtrim($str,'/');
    echo $str_new;
?>

<?php 
    echo "15. Write a PHP script to get the characters after the last '/' in an url. ";
    echo "<br>";
    $str = 'http://www.example.com/5478631';
    echo $str."<br>";
    echo substr($str,strrpos($str,'/')+1)."\n";
?>

<?php
    echo "16. Write a PHP script to select first 5 words from the following string. ";
    $str = 'The quick brown fox jumps over the lazy dog';
    echo "<br>";
    echo implode(' ',array_slice(explode(' ',$str),0,5));

?>

<?php
    echo "16. Write a PHP script to select first 5 words from the following string. ";
    $str = 'The quick brown fox jumps over the lazy dog';
    echo "<br>";
    echo implode(' ',array_slice(explode(' ',$str),0,5));

?>

<?php
    echo "17. Write a PHP script to remove comma(s) from the following numeric string.";
    echo "<br>";
    echo $str = '2,543.12';
    echo "<br>";
    $str = str_replace(',','',$str);
    echo $str;
?>
<?php
    echo "18. Write a PHP script to print letters from 'a' to 'z'. ";
    
    for($i=97;$i<123;$i++){
        echo "<br>".chr($i);
    }

?>
