<?php
    echo "7. Write a PHP script to replace the first 'the' of the following string with 'That'.";
    $str = 'the quick brown fox jumps over the lazy dog.';
    echo "<br>";    
    echo $str;
    echo "<br>";
    echo preg_replace('/the/','That',$str,1)."\n";
?>