<?php
    echo "13. Write a PHP script to remove part of a string.";
    echo "<br>";
    $str = 'The quick brown fox jumps over the lazy dog';
    echo $str."<br>";
    $strr = 'for';
    $new_str = str_replace('fox',' ',$str);
    echo $new_str;

?>