<?php
    echo "5. Write a PHP script to get the last three characters of a string. ";
    echo "<br>";
    $str = "ray@example.com";
    echo "<br>";
    $strnew = substr($str,-3);
    echo $strnew;
?>