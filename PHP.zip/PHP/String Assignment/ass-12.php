<?php 
    echo "12. Write a PHP script to remove all leading zeroes from a string. ";
    echo "<br>";
    $str = '000547023.24';
    $str_new = ltrim($str,'0');
    echo $str."<br>".$str_new;  
?>