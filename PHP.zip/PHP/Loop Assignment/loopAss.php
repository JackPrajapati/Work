<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="main.css" />
</head>
<body>
    <h1><center>Loop Assignment</center></h1>
    <h4>1. Create a script that displays 1-2-3-4-5-6-7-8-9-10 on one line without (-) hypen sign in between.</h4>
    <b>Ans:</b>
    <?php 
        for($i = 1; $i <= 10; $i++)
        {
            echo "$i ";
        }
    ?>

    <h4>2. Create a script using a for loop to add all the integers between 0 and 30 and display the total. </h4>
    <b>Ans:</b>
    <?php 
        $sum = 0;
        for($i = 0; $i <= 30; $i++)
        {
            $sum += $i;
        }
        echo "Sum = $sum";

    ?>

    <h4>3. Create a script to construct the following pattern, using for loop. </h4>
    <b>Ans:</b></br>
    <?php 
        for($i = 0; $i < 5; $i++)
        {
            for($j = 0; $j <=$i; $j++)
                echo "*  &nbsp;&nbsp;&nbsp;";
            echo "</br>";
        }
    ?>

    <h4>4. Create a script to construct the following pattern, using a for loop.</h4>
    <b>Ans:</b></br>
    <?php 
        $n = 5;
        for($i = 0; $i < $n; $i++)
        {
            for($j = 0; $j <=$i; $j++)
            {
                echo "*  &nbsp;&nbsp;&nbsp;";
            }
            echo "</br>";
        }

        for($i = $n; $i > 0; $i--)
        {
            for($j = 0; $j < $i ; $j++)
            {
                echo "*  &nbsp;&nbsp;&nbsp;";
            }
            echo "</br>";
        }
    ?>

    <h4>5. Write a program to calculate and print the factorial of a number using a for loop. The factorial of a number is the product of all integers up to and including that number, so the factorial of 4 is 4*3*2*1= 24. </h4>
    <b>Ans:</b></br>
    <?php
        // $fact = 1;
        // for($i = 1; $i <= 4; $i++)
        // {
        //     $fact = $fact * $i;
        //     echo "$i * ";
        // }
        // echo "= $fact";

    ?>
    <b>Enter Number:</b>
    <form method="Post" action="">
        <input type="number" name="facto" id="facto">
        <input type="submit" name="submit" Value="Click">
    </form>
    <?php
        $num = $_POST['facto']; 
        $fact = 1;
        if(isset($_POST['submit']))
        {
            for($i = 1; $i <= $num; $i++)
            {
                $fact = $fact * $i;
            }
            echo "<br>";
            echo "Factorial of $num is : $fact";
        } 
        ?>

    <h4>6. Write a program which will give you all of the potential combinations of a two-digit decimal combination, printed in a comma delimited format :</h4>
    <b>Ans:</b></br>
    <?php
        
        for($a = 0; $a <= 9; $a++)
        {
            for($b = 0; $b <= 9; $b++)
            {
                echo $a.$b.", ";
            }
        }
        echo "<br>";
    ?>

    <h4>7. Write a program which will count the "r" characters in the text "raibareli". </h4>
    <b>Ans:</b></br>
    <?php
        $str = "raibareli";
        $count;
        for($a = 0; $a <= strlen($str); $a++)
        {
            if($str[$a] == "r")
            {
                $count++;
            }
        }
        echo "'r' in raibareli : $count";
    ?>

    <h4>8. Write a PHP script that creates the following table (use for loops).  </h4>
    <b>Ans:</b></br>
    <?php
        echo "<table id='ass8_table' border='2'>";
        for($i = 1; $i <= 10 ; $i++)
        {
            echo "<tr>";
            for($j = 1; $j <= 10; $j++)
            {
                echo "<td>".$j*$i."</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    ?>

    <h4>9. Write a PHP program which iterates the integers from 1 to 100. For multiples of three print "Hello" instead of the number and for the multiples of five print "World". For numbers which are multiples of both three and five print "HelloWorld".</h4>
    <b>Ans:</b></br>
    <?php
        for($i = 1; $i <= 100; $i++)
        {
            if($i % 3 == 0)
                echo "Hello <br>";
            if($i % 5 == 0)
                echo "World <br>";
            if($i % 3 == 0 && $i % 5 == 0)
                echo "Hello World <br>";
        }
    ?>

    <h4>10. Use for loops to print this pattern:</h4>
    <b>Ans:</b></br>
    <?php
        for($i = 1; $i <= 5; $i++)
        {
            for($j = 5; $j >= $i; $j--)
            {
                echo "* ";
            }
            echo "<br>";
        }
    ?>


    <h4>11. Write a PHP program to print Fibonacci series using while loop.</h4>
    <b>Ans:</b></br>
    <h5>Enter number to genarate Fibonacci Series:<h5>
    <form method="Post" action="loopAss.php">
        <input type="number" name="fibonacci">
        <input type="submit" name="Fibo">
    </form>
    <?php
        if(isset($_POST['Fibo']))
        {
            fibb();
        } 
        function fibb()
        {
            $num = $_POST['fibonacci'];
            // echo $num;  
            $num1 = 0;
            $num2 = 1;     
            echo "<br>Series: $num1 $num2 ";
            while($num > 0)
            {
                $num3 = $num1 + $num2;
                echo "$num3 ";
                $num1 = $num2;
                $num2 = $num3;
                $num--;               
            }
        }
    ?>

    <h4>12.  Swapping of two numbers without using Third variable.</h4>
    <b>Ans:</b></br>
    <?php
        $a = 20;
        $b = 30;
        echo "<br>Before swap: a = $a, b = $b";
        $a = $a + $b;
        $b = $a - $b;
        $a = $a - $b;
        echo "<br>After swap: a = $a, b = $b";
    ?>
</body>
</html>