<?php
    echo "18. Write a PHP program to get the index of the highest value in an associative array.";
    $x = array(
        'value1' => 3021,
        'value2' => 2365,
        'value3' => 5215,
        'value4' => 5214,
        'value4' => 2145);
    arsort($x);
    $key_of_max = key($x);
    echo "Index of highest value : ".$key_of_max."\n";

?>