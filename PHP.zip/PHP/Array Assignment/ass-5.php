<?php
    echo "5. Write a PHP script to sort the following associative array : ";
    $arr = array("Sophia" => "31", "Jacob" => "41", "William" => "39", "Ramesh" => "40");
    echo "<pre>";
    print_r($arr);
    echo "a) ascending order sort by value";
    asort($arr);

    foreach($arr as $x=>$y)
    {
        echo "<br> $x's age is $y.";
    }

    echo "<br>b) ascending order sort by Key";
    ksort($arr);

    foreach($arr as $x=>$y)
    {
        echo "<br> $x's age is $y.";
    }

    echo "<br>c) descending order sorting by Value";
    arsort($arr);

    foreach($arr as $x=>$y)
    {
        echo "<br> $x's age is $y.";
    }

    echo "<br>d) descending order sorting by Key";
    krsort($arr);

    foreach($arr as $x=>$y)
    {
        echo "<br> $x's age is $y.";
    }

?>