<?php
    echo "42. Write a PHP script to combine (using one array for keys and another for its values) the following two arrays.
    ('x', 'y', 'y'), (10, 20, 30)";
    $keys = ['x', 'y', 'y'];
    $values = ['10', '20', '30'];
     
    $array = array_combine($keys, $values);
    echo "<pre>";
    print_r($array);

?>