<?php
    echo "8. Write a PHP script to get the shortest/longest string length from an array. ";
    $myarray = array('abcd','abc','de','hjjj','g','wer');
    $new_array = array_map('strlen',$myarray);

    echo "<br>The shortest array lenth is " .min($new_array).
    ".<br> The longest array length is " .max($new_array).'.';

?>