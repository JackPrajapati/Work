<?php
    echo "23. Write a PHP script to count the total number of times a specific value appears in an array.";
    function count_array_values($my_array,$match)
    {
        $count = 0;
        foreach($my_array as $key => $value)
        {
            if($value == $match)
            {
                $count++;
            }
        }
        return $count;
    }

    $colors =array("c1"=>"Red", "c2" =>"Green","c3"=>"Yellow","c4"=>"Red");
    echo "<br>"."red colors appears ".count_array_values($colors,"Red")." times."."\n";
?>