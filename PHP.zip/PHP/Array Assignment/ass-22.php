<?php
    echo "22. Write a PHP script to lower-case and upper-case, all elements in an array.";
    $colors = array("Red","Green","Black","White");
    echo "<pre>";
    print_r($colors);
    $lower_color = array_map('strtolower',$colors);
    print_r($lower_color);
    $upper_color = array_map('strtoupper',$colors);
    print_r($colors);
?>