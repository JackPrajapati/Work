<?php
    echo "Delete an element from the above PHP array. After deleting the element, integer keys must be normalized. ";
    echo "<pre>";
    $x = array(1,2,3,4,5,6);
    var_dump($x);
    unset($x[2]);
    var_dump($x);
    $x = array_values($x);
    var_dump($x);
    echo "</pre>";
?>