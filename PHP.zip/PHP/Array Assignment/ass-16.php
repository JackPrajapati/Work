<?php
    echo "16. Write a PHP script to sort an array in reverse order (highest to lowest).";
    $colors = array("Red", "Orange", "Black", "White");
    rsort($colors);
    echo "<br><pre>";
    
    print_r($colors);

?>