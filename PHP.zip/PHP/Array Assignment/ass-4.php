<?php
    echo "4. Write a PHP script that inserts a new item in an array in any position. ";
    $original_array = array('1','2','3','4','5');
    $inserted = '$';
    echo "<pre>";
    echo "<br>";
    print_r($original_array);
    echo "<br>";
    array_splice($original_array,3,0,$inserted);
    echo "<br>";
    print_r($original_array);
?>