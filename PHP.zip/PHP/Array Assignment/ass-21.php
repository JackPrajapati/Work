<?php
    echo "21. Write a PHP script to trim all the elements in an array using array_walk function.";
    $color = array("Red", "Green", "Black" ,"White");
    echo "<pre>";
    print_r($color);
    array_walk($color,create_function('&$val','$val = trim($val);'));
    print_r($color);

?>