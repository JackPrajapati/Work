<?php
    echo "Write a PHP script which will display the colors in the following way : ";
    $color = array('white','green','red');
    echo "<br>";
    foreach($color as $c)
    {
        echo "$c, ";
    }
?>