<?php
    echo "Write a PHP script to get the first element of the above array. ";
    $color = array(4 => 'white', 6 => 'green', 11 => 'red');
    echo "<br>".reset($color);
?>