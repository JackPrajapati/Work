<?php
    echo "9. Write a PHP script to generate unique random numbers within a range.";
    $n = range(11,20);
    shuffle($n);
    echo "<br>";
    for($x=0; $x<10 ; $x++)
    {
        echo $n[$x].' ';
    }  

?>