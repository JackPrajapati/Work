<?php
    echo "29. Write a PHP a function to remove a specified, duplicate entry from an array.";
    function array_uniq($my_array,$value)
    {
        $count = 0;
        foreach ($my_array as $arrkey => $arrvalue) {
            if( ($count > 0) && ($arrvalue == $value) )
            {
                unset($my_array[$arrkey]);
            }
            if($arrvalue == $value) $count++;
        }
        return array_filter($my_array);
    }
    $numbers = array(4,5,6,7,4,7,8);

    echo "<pre>";
    print_r(array_uniq($numbers,7));
?>