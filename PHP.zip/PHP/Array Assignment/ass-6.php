<?php
    echo "6. Write a PHP script to calculate and display average temperature, five lowest and highest temperatures.";
    $temp_str =  array(78,60,62,68,71,68,73,85,66,64,76,63,75,76,73,68,62,73,72,65,74,62,62,65,64,68,73,75,79,73);

    $total = count($temp_str);
    $sum = array_sum($temp_str);

    // echo $total;
    // echo $sum;

    $avg = $sum / $total;
    echo "<br>";
    echo round($avg);
    
    $uniq = array_unique($temp_str);
    sort($uniq);

    echo "<br>";
    for ($i=0; $i < 7; $i++) { 
        echo $uniq[$i].' ';
    }

    echo "<br>";
    for ($i=(count($uniq)-7); $i < (count($uniq)); $i++) { 
        echo $uniq[$i].' ';
    }

?>