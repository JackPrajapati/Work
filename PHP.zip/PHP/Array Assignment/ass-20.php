<?php
    echo "20. Write a PHP program to sort an associative array (alphanumeric with case-sensitive data) by values.";
    $test_array = array(
        0 => "example1",
        1 => 'Example2',
        2 => 'example10',
        3 => 'example6',
        4 => 'example4',
        5 => 'EXAMPLE40',
        6 => 'example10');
    asort($test_array,SORT_STRING | SORT_FLAG | SORT_NATURAL);
    echo "<pre>";
    print_r($test_array);
?>