<?php
    echo "26. Write a PHP program to get a sorted array without preserving the keys.";
    $myarray = array("red","black","green","black","white","yellow");
    $sorted_unique_array = array_values(array_unique($myarray));
    echo "<pre>";
    print_r($sorted_unique_array);
?>