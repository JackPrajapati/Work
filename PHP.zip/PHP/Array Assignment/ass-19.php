<?php
    echo "19. Write a PHP function to search a specified value within the values of an associative array.";
    function arraysearch($arr1,$search)
    {
        reset($arr1);
        while(list ($key ,$val) = each($arr1))
        {
            if(preg_match("/$search/i",$val))
            {
                echo $search." has found in ".$key."<br>";
            }
            else
            {
                echo $search." has not found in".$key."<br>";
            }

        }
    }

    $exercises =array("part1"=>"PHP array","part2"=>"PHP string", "part3"=>"PHP math");
    arraysearch($exercises,"Math");
?>