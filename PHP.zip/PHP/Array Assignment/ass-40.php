<?php
    echo "43. Write a PHP program to create a range like the following array.
    Array ";
    echo "<pre>";
    print_r(array_combine(range(20,25),range(2,7)));
?>