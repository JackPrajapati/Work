<?php
    echo "34. Write a PHP script to get an array containing all the entries of an array which have the keys that are present in another array.";
    $first_array = array('c1' => 'Red', 'c2' => 'Green', 'c3' => 'White', 'c4' => 'Black'); 
    $second_array = array('c2', 'c4'); 
    echo "<pre>";
    print_r(array_intersect_key($first_array,array_flip($second_array)));
?>